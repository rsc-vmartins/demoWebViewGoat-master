WebViewGoat
===========

This is an Android application designed to read QRCodes that contain web links.

For now it works only using the device camera but in the future it will read
QRCodes from the filesystem. The result is loaded in a WebView.

## How to run

For that you need to define the following:

1. The WebView URL: on the MainActivity there is a variable that defines this,
   called webviewURL. Update it to point to your web server. Make sure that
   your web server is serving the proper HTML file (index.html) that will be
   loaded by the WebView.

2. Compile and install on your device!

